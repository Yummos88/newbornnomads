# The Newborn Nomads — Media Kit (bron)

PDF opnieuw genereren:

    pip install weasyprint
    python3 build.py

Bestanden:
  mediakit.html          de volledige kit (8 pagina's A4) — hier pas je tekst aan
  build.py               rendert mediakit.html naar PDF
  stamp.png              het stempellogo (transparant)
  portret_vierkant.jpg   coverfoto (liggend, 174x118mm kader)
  gezinsfoto_cover.jpg   ronde foto pagina 2 (vierkant)
  fonts/                 Fraunces (koppen), Karla (tekst), IBM Plex Mono (labels)

Laatst gewijzigd: oktober 2026
  - nieuwe gezinsfoto's
  - contactadres hello@thenewbornnomads.com

Let op:
- Cover (p1) en routekaart (p6) zijn bewust zo gelaten; niet herontwerpen.
- Locatie staat op twee plekken hard in de tekst: "CURRENTLY IN THE NETHERLANDS"
  op de cover en de routekaart op p6. Bijwerken bij elke landwissel.
