from weasyprint import HTML
HTML('mediakit.html', base_url='.').write_pdf('TheNewbornNomads-MediaKit-2026-10.pdf')
print("PDF gebouwd")
